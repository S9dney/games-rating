const BASE_URL = 'https://api-code-2.practicum-team.ru';
const endpoint = {
    games: `${BASE_URL}/games`,
};

module.exports = endpoint;